@extends('layouts.presensi')
@section('header')
<!-- {{-- App Header --}} -->
<div class="appHeader bg-primary text-light">
    <div class="left">
        <a href="javascript:;" class="headerButton goBack">
            <ion-icon name="chevron-back-outline"></ion-icon>
        </a>
    </div>
    <div class="pageTittle">Data Izin / Sakit</div>
    <div class="right"></div>
</div>
<!-- {{-- App Header --}} -->
@endsection

@section('content')
<div class="row">
    <div class="col" style="margin-top: 70px;">
    @php
            $messagesuccess = Session::get('success');
            $messageerror = Session::get('error');
        @endphp
        @if (Session::get('success'))
        <div class="alert alert-success">
            {{$messagesuccess}}
        </div>
        @endif
        @if (Session::get('error'))
        <div class="alert alert-danger">
            {{$messageerror}}
        </div>
        @endif
    </div>
</div>
    <div class="fab-button bottom-right" style="margin-bottom: 70px">
        <a href="/presensi/buatizin" class="fab">
            <ion-icon name="add-outline"></ion-icon>
        </a>
    </div>
@endsection


<!-- @section('content')
<div class="fab-button buttom-right" style="margin-bottom: 70px">
    <a href="#" class="fab">
        <ion-icon name="add-circle-outline"></ion-icon>
    </a>
</div>
@endsection -->
