<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\RiakServiceProvider::class,
    App\Providers\RouteServiceProvider::class,
];
